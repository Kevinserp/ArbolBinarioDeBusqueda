
package Trabajo1;

public class Nodo {
     String producto;
    Nodo izquierdo, derecho;

    public Nodo(String producto) {
        this.producto = producto;
        izquierdo = derecho = null;
    }
}  

