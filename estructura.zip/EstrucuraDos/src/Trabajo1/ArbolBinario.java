
package Trabajo1;

public class ArbolBinario {
   Nodo raiz;

    public ArbolBinario() {
        raiz = null;
    }

    // Método para insertar un nuevo nodo en el árbol
    public void insertar(String producto) {
        raiz = insertarRecursivo(raiz, producto);
    }

    private Nodo insertarRecursivo(Nodo raiz, String producto) {
        if (raiz == null) {
            raiz = new Nodo(producto);
            return raiz;
        }
        if (producto.compareTo(raiz.producto) < 0) {
            raiz.izquierdo = insertarRecursivo(raiz.izquierdo, producto);
        } else if (producto.compareTo(raiz.producto) > 0) {
            raiz.derecho = insertarRecursivo(raiz.derecho, producto);
        }
        return raiz;
    }

    // Método para buscar un nodo
    public boolean buscar(String producto) {
        return buscarRecursivo(raiz, producto) != null;
    }

    private Nodo buscarRecursivo(Nodo raiz, String producto) {
        if (raiz == null || raiz.producto.equals(producto)) {
            return raiz;
        }
        if (producto.compareTo(raiz.producto) < 0) {
            return buscarRecursivo(raiz.izquierdo, producto);
        }
        return buscarRecursivo(raiz.derecho, producto);
    }

    // Método para eliminar un nodo
    public void eliminar(String producto) {
        raiz = eliminarRecursivo(raiz, producto);
    }

    private Nodo eliminarRecursivo(Nodo raiz, String producto) {
        if (raiz == null) return raiz;

        if (producto.compareTo(raiz.producto) < 0)
            raiz.izquierdo = eliminarRecursivo(raiz.izquierdo, producto);
        else if (producto.compareTo(raiz.producto) > 0)
            raiz.derecho = eliminarRecursivo(raiz.derecho, producto);
        else {
            if (raiz.izquierdo == null)
                return raiz.derecho;
            else if (raiz.derecho == null)
                return raiz.izquierdo;

            raiz.producto = minValor(raiz.derecho);
            raiz.derecho = eliminarRecursivo(raiz.derecho, raiz.producto);
        }
        return raiz;
    }

    private String minValor(Nodo raiz) {
        String minv = raiz.producto;
        while (raiz.izquierdo != null) {
            minv = raiz.izquierdo.producto;
            raiz = raiz.izquierdo;
        }
        return minv;
    }

    // Método para mostrar los productos en inorden
    public void mostrarInorden() {
        inordenRecursivo(raiz);
    }

    private void inordenRecursivo(Nodo raiz) {
        if (raiz != null) {
            inordenRecursivo(raiz.izquierdo);
            System.out.println(raiz.producto);
            inordenRecursivo(raiz.derecho);
        }
    }
}  

