
package Trabajo1;

public class Main {
     public static void main(String[] args) {
        ArbolBinario arbol = new ArbolBinario();
        arbol.insertar("Zapatos");
        arbol.insertar("Camisa");
        arbol.insertar("Pantalón");

        System.out.println("Inorden:");
        arbol.mostrarInorden();

        System.out.println("\n¿Existe Pantalón? " + arbol.buscar("Pantalón"));
        
        arbol.eliminar("Pantalón");
        System.out.println("\nDespués de eliminar Pantalón:");
        arbol.mostrarInorden();
    }
}

